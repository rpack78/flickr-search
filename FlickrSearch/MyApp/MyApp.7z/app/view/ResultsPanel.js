Ext.define('MyApp.view.ResultsPanel', {
  extend: 'Ext.panel.Panel',

  xtype: 'resultspanel',
  html: 'resultspanel',
  layout: 'hbox'

});