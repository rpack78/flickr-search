This folder contains the views
