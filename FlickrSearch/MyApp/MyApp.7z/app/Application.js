Ext.define('MyApp.Application', {
    name: 'MyApp',

    extend: 'Ext.app.Application',

    controllers: [
        'Main'
    ]
});
