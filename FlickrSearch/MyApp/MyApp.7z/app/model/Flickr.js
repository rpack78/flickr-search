Ext.define('MyApp.model.Flickr', {
	extend: 'Ext.data.Model',
	fields: ['media', 'author']
});